function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
    if (input == "hello everyone") {
        return "Hey Wssup";
    } else if (input == "I am Shivam Kushwaha") {
        return "Welcome to openboard chatbox";
    } else {
        return "Try Connecting Multiple clients";
    }
}